package com.metaperceptexerses.onepageweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnepagewebApplicationTests {

	@Test
	void contextLoads() {
	}

}
