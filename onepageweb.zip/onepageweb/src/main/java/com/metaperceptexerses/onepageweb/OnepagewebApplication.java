package com.metaperceptexerses.onepageweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnepagewebApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnepagewebApplication.class, args);
	}

}
